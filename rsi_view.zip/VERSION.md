# VERSION

## v1
화면 : Github Page
배치 : Github Action
기능
- RSI 기능 지표

## v1.1
requirements로 패키지 변경하도록 변경 수행

## v2
per, pbr, roe, eps 지표 추가

# 추가 필요 요구사항
python 64bit -> pandas 설치